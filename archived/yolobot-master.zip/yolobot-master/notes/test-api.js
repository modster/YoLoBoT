// I m p o r t  N o d e - B i n a n c e - A p i
//const binance = require('./modster-binance/head0.js');
const api = require('./modster-binance/binance.js');
//const direction = 'buy', symbol = 'USDT', pair = 'BTC', quantity = 0.001

//async function quantity () {

// F u t u r e s  B a l a n c e
async function marketOrder (direction, symbol, quantity) {
  try {
    let response = await binance.futuresBalance()
    response.forEach(function(item) {
      const {accountAlias, asset, balance, withdrawlAvailable, updateTime} = item
      //console.log(accountAlias, asset, balance, withdrawlAvailable, updateTime)
      if(asset === symbol) {
        console.log(asset, balance)
        return
      } 
      console.log(asset, balance)
    })
    if(direction == 'buy') {
      api.marketBuy()
    } 
    else if (direction == 'sell') {
      api.marketBuy.sell
    }
    else {
      console.log('error')
    }
    } catch (error) {
    console.error(error)
  }
}
marketOrder('buy', 'USDT', 0.01)