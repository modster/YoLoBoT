try {
  req.body
} catch (error) {
  return res.status(400).json({ error: 'My custom 400 error' })
}