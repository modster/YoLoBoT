
// Endpoint: https://node-echo-api.now-examples.now.sh/api/?name=example
// https://vercel.com/docs/v2/serverless-functions/introduction#an-example-node.js-serverless-function
module.exports = (req, res) => {
  res.json({
    body: req.body,
    query: req.query,
    cookies: req.cookies
  })
}